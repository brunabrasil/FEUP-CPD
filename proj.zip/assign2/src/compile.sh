#!/usr/bin/env bash

javac .\Authentication.java .\AuthenticationThread.java .\GameThread.java .\Client.java .\Player.java .\Registration.java .\Server.java .\SocketChannelUtils.java .\TokenWithExpiration.java